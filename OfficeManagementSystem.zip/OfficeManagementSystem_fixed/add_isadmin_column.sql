-- Run this once in MySQL to add the IsAdmin column to your Users table
-- if it doesn't already exist.

ALTER TABLE Users
ADD COLUMN IsAdmin VARCHAR(3) NOT NULL DEFAULT 'No';

-- Then set your admin user(s):
-- UPDATE Users SET IsAdmin = 'Yes' WHERE UserName = 'admin';
