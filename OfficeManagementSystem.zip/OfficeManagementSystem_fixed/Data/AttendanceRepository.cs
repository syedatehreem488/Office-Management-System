﻿using MySql.Data.MySqlClient;
using OfficeManagementSystem.Models;

namespace OfficeManagementSystem.Data
{
    public class AttendanceRepository
    {
        private readonly string _connectionString;

        public AttendanceRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Get all attendance records
        public List<Attendance> GetAllAttendance()
        {
            List<Attendance> attendanceList = new List<Attendance>();

            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();

                string query = @"SELECT * FROM Attendance";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            attendanceList.Add(new Attendance
                            {
                                AttendanceID = Convert.ToInt32(reader["AttendanceID"]),
                                EmployeeID = Convert.ToInt32(reader["EmployeeID"]),
                                AttendanceDate = Convert.ToDateTime(reader["AttendanceDate"]),
                                ClockInTime = TimeSpan.Parse(reader["ClockInTime"].ToString()),
                                ClockOutTime = TimeSpan.Parse(reader["ClockOutTime"].ToString()),
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }
            }

            return attendanceList;
        }

        // Get attendance by employee
        public List<Attendance> GetAttendanceByEmployee(int employeeId)
        {
            List<Attendance> attendanceList = new List<Attendance>();

            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();

                string query = @"SELECT * 
                                 FROM Attendance
                                 WHERE EmployeeID = @EmployeeID";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmployeeID", employeeId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            attendanceList.Add(new Attendance
                            {
                                AttendanceID = Convert.ToInt32(reader["AttendanceID"]),
                                EmployeeID = Convert.ToInt32(reader["EmployeeID"]),
                                AttendanceDate = Convert.ToDateTime(reader["AttendanceDate"]),
                                ClockInTime = TimeSpan.Parse(reader["ClockInTime"].ToString()),
                                ClockOutTime = TimeSpan.Parse(reader["ClockOutTime"].ToString()),
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }
            }

            return attendanceList;
        }
    }
}