﻿using MySql.Data.MySqlClient;
using OfficeManagementSystem.Models;
using System.Data;

namespace OfficeManagementSystem.Data
{
    public class PayrollRepository
    {
        private readonly string _connectionString;

        public PayrollRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Get all payroll records
        public List<Payroll> GetAllPayroll()
        {
            List<Payroll> payrolls = new List<Payroll>();

            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM Payroll";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        payrolls.Add(new Payroll
                        {
                            PayrollID = Convert.ToInt32(reader["PayrollID"]),
                            EmployeeID = Convert.ToInt32(reader["EmployeeID"]),
                            Bonus = Convert.ToInt32(reader["Bonus"]),
                            Deduction = Convert.ToInt32(reader["Deduction"]),
                            NetSalary = Convert.ToInt32(reader["NetSalary"]),
                            PaymentDate = Convert.ToDateTime(reader["PaymentDate"]),
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            return payrolls;
        }

        // Call CalculatePayroll stored procedure
        public void ProcessPayroll(
            int employeeId,
            int bonus,
            int deduction,
            DateTime paymentDate)
        {
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand("CalculatePayroll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("in_EmployeeID", employeeId);
                    cmd.Parameters.AddWithValue("in_Bonus", bonus);
                    cmd.Parameters.AddWithValue("in_Deduction", deduction);
                    cmd.Parameters.AddWithValue("in_PaymentDate", paymentDate);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}