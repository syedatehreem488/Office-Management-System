using Microsoft.AspNetCore.Mvc;
using OfficeManagementSystem.Data;
using OfficeManagementSystem.Models;

namespace OfficeManagementSystem.Controllers
{
    public class LeaveController : Controller
    {
        private readonly LeaveRepository _leaveRepository;

        public LeaveController(LeaveRepository leaveRepository)
        {
            _leaveRepository = leaveRepository;
        }

        // Helper: check session
        private bool IsLoggedIn() => HttpContext.Session.GetString("UserName") != null;
        private bool IsAdmin() => HttpContext.Session.GetString("IsAdmin") == "Yes";
        private int GetEmployeeID() => HttpContext.Session.GetInt32("EmployeeID") ?? 0;

        // Employee: view own leaves + submit form
        public IActionResult Index()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            if (IsAdmin()) return RedirectToAction("Admin");

            var myLeaves = _leaveRepository.GetLeavesByEmployee(GetEmployeeID());
            return View(myLeaves);
        }

        // Employee: submit new leave request
        [HttpPost]
        public IActionResult Submit(LeaveRequest leave)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            leave.EmployeeID = GetEmployeeID();
            _leaveRepository.SubmitLeave(leave);

            return RedirectToAction("Index");
        }

        // Admin: view all leaves + approve/reject
        public IActionResult Admin()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index"); // employees can't access this

            var allLeaves = _leaveRepository.GetAllLeaves();
            return View(allLeaves);
        }

        // Admin: approve a leave
        public IActionResult Approve(int id)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _leaveRepository.ApproveLeave(id, "Approved");
            return RedirectToAction("Admin");
        }

        // Admin: reject a leave
        public IActionResult Reject(int id)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _leaveRepository.ApproveLeave(id, "Rejected");
            return RedirectToAction("Admin");
        }
    }
}
