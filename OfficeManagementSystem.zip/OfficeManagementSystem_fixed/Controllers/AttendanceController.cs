using Microsoft.AspNetCore.Mvc;
using OfficeManagementSystem.Data;

namespace OfficeManagementSystem.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly AttendanceRepository _attendanceRepository;

        public AttendanceController(AttendanceRepository attendanceRepository)
        {
            _attendanceRepository = attendanceRepository;
        }

        private bool IsLoggedIn() => HttpContext.Session.GetString("UserName") != null;

        public IActionResult Index()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            var attendance = _attendanceRepository.GetAllAttendance();
            return View(attendance);
        }
    }
}
