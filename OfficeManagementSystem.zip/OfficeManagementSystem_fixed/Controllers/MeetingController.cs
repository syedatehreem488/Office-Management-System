using Microsoft.AspNetCore.Mvc;
using OfficeManagementSystem.Data;
using OfficeManagementSystem.Models;

namespace OfficeManagementSystem.Controllers
{
    public class MeetingsController : Controller
    {
        private readonly MeetingRepository _meetingRepository;

        public MeetingsController(MeetingRepository meetingRepository)
        {
            _meetingRepository = meetingRepository;
        }

        private bool IsLoggedIn() => HttpContext.Session.GetString("UserName") != null;
        private bool IsAdmin() => HttpContext.Session.GetString("IsAdmin") == "Yes";

        public IActionResult Index()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            var meetings = _meetingRepository.GetAllMeetings();
            return View(meetings);
        }

        public IActionResult Create()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            return View();
        }

        [HttpPost]
        public IActionResult Create(Meeting meeting)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _meetingRepository.AddMeeting(meeting);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            var meeting = _meetingRepository.GetMeetingById(id);
            return View(meeting);
        }

        [HttpPost]
        public IActionResult Edit(Meeting meeting)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _meetingRepository.UpdateMeeting(meeting);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _meetingRepository.DeleteMeeting(id);
            return RedirectToAction("Index");
        }
    }
}
