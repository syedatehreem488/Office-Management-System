using Microsoft.AspNetCore.Mvc;
using OfficeManagementSystem.Data;

namespace OfficeManagementSystem.Controllers
{
    public class PayrollController : Controller
    {
        private readonly PayrollRepository _payrollRepository;

        public PayrollController(PayrollRepository payrollRepository)
        {
            _payrollRepository = payrollRepository;
        }

        private bool IsLoggedIn() => HttpContext.Session.GetString("UserName") != null;
        private bool IsAdmin() => HttpContext.Session.GetString("IsAdmin") == "Yes";

        public IActionResult Index()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            var payrolls = _payrollRepository.GetAllPayroll();
            return View(payrolls);
        }

        [HttpPost]
        public IActionResult Process(int employeeId, int bonus, int deduction, DateTime paymentDate)
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            if (!IsAdmin()) return RedirectToAction("Index");

            _payrollRepository.ProcessPayroll(employeeId, bonus, deduction, paymentDate);
            return RedirectToAction("Index");
        }
    }
}
