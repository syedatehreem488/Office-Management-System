using Microsoft.AspNetCore.Mvc;
using OfficeManagementSystem.Data;

namespace OfficeManagementSystem.Controllers
{
    public class DashboardController : Controller
    {
        private readonly DashboardRepository _dashboardRepository;

        public DashboardController(DashboardRepository dashboardRepository)
        {
            _dashboardRepository = dashboardRepository;
        }

        private bool IsLoggedIn() => HttpContext.Session.GetString("UserName") != null;

        public IActionResult Index()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");

            var summary = _dashboardRepository.GetAttendanceSummary();
            return View(summary);
        }
    }
}
