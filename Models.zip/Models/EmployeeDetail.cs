﻿namespace OfficeManagementSystem.Models
{
    public class EmployeeDetail
    {
        public int EmployeeID { get; set; }

        public string EmployeeName { get; set; }

        public string DepartmentName { get; set; }

        public string RoleName { get; set; }

        public decimal BasicSalary { get; set; }
    }
}